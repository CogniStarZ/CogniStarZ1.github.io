const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

// 配置
const BASE_URL = 'https://www.zhiqiantong.cn';
const SEARCH_URL = `${BASE_URL}/front/job/search`;
const DETAIL_URL = `${BASE_URL}/front/job/desc`;

// 方向关键词映射
const DIRECTION_KEYWORDS = {
  '云计算': ['云计算', 'Cloud', '虚拟化', '容器', 'K8s', 'Docker'],
  '大数据': ['大数据', 'Hadoop', 'Spark', 'Flink', 'ETL', '数据仓库'],
  'AI人工智能': ['AI', '人工智能', '机器学习', '深度学习', '计算机视觉', 'NLP', '大模型'],
  '鸿蒙与终端': ['鸿蒙', 'HarmonyOS', 'ArkTS', 'ArkUI', '嵌入式', '物联网'],
  '华为Datacom数通': ['数通', 'Datacom', '路由', '交换', '网络工程师', 'WLAN', 'SD-WAN']
};

// HTTP 请求配置
const axiosConfig = {
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
  },
  timeout: 30000
};

/**
 * 抓取职位列表页
 */
async function fetchJobList() {
  console.log('正在抓取职位列表...');
  try {
    const response = await axios.get(SEARCH_URL, axiosConfig);
    const $ = cheerio.load(response.data);
    const jobs = [];

    // 解析职位卡片
    $('.job-list-item, .job-card, [class*="job"]').each((i, el) => {
      const $el = $(el);
      const link = $el.find('a[href*="/front/job/desc/"]').attr('href');
      
      if (link) {
        const idMatch = link.match(/\/front\/job\/desc\/(\d+)/);
        if (idMatch) {
          const id = idMatch[1];
          const title = $el.find('h3, .job-title, [class*="title"]').first().text().trim();
          const salary = $el.find('.salary, [class*="salary"]').text().trim();
          const location = $el.find('.location, [class*="city"], [class*="area"]').text().trim();
          
          jobs.push({ id, title, salary, location, url: `${BASE_URL}/front/job/desc/${id}` });
        }
      }
    });

    console.log(`从列表页发现 ${jobs.length} 个职位`);
    return jobs;
  } catch (error) {
    console.error('抓取列表页失败:', error.message);
    return [];
  }
}

/**
 * 抓取单个职位详情
 */
async function fetchJobDetail(jobId) {
  const url = `${DETAIL_URL}/${jobId}`;
  try {
    const response = await axios.get(url, axiosConfig);
    const $ = cheerio.load(response.data);

    const job = {
      id: jobId,
      url: url,
      title: '',
      salary: '',
      city: '',
      exp: '',
      edu: '',
      cert: null,
      company: '',
      company_url: '',
      duty: '',
      extra: '',
      match_our_jobs: [],
      fit_stage: 'target',
      verified: false
    };

    // 提取基本信息
    job.title = $('h1, .job-title, [class*="title"]').first().text().trim();
    
    // 提取薪资
    const salaryEl = $('.salary, [class*="salary"], [class*="pay"]');
    job.salary = salaryEl.text().trim() || '面议';

    // 提取工作地点
    const locationText = $('.location, [class*="city"], [class*="address"]').text().trim();
    job.city = locationText.split('·')[0] || locationText;

    // 提取经验和学历
    const infoItems = $('.job-info span, .info-item, [class*="requirement"]');
    infoItems.each((i, el) => {
      const text = $(el).text().trim();
      if (text.includes('年') || text.includes('经验')) {
        job.exp = text;
      }
      if (text.includes('学历') || text.includes('大专') || text.includes('本科') || text.includes('硕士')) {
        job.edu = text.replace('学历：', '').trim();
      }
    });

    // 提取证书要求
    const certText = $('.cert, [class*="cert"], [class*="证书"]').text().trim();
    if (certText && certText.length < 100) {
      job.cert = certText;
    }

    // 提取公司信息
    const companyLink = $('a[href*="/front/company/desc"]');
    if (companyLink.length > 0) {
      job.company = companyLink.text().trim();
      job.company_url = BASE_URL + companyLink.attr('href');
    }

    // 提取工作职责
    const dutySection = $('.job-desc, .responsibility, [class*="duty"], [class*="职责"]');
    job.duty = dutySection.text().trim().substring(0, 500);

    // 提取补充说明
    const extraSection = $('.job-requirement, .qualification, [class*="requirement"], [class*="要求"]');
    const extraText = extraSection.text().trim();
    if (extraText && extraText !== job.duty) {
      job.extra = extraText.substring(0, 500);
    }

    // 根据职位标题推断匹配的本平台岗位和方向
    job.match_our_jobs = inferMatchingJobs(job.title);
    job.fit_stage = inferFitStage(job.exp, job.edu);

    job.verified = true;
    return job;
  } catch (error) {
    console.error(`抓取职位 ${jobId} 详情失败:`, error.message);
    return null;
  }
}

/**
 * 根据职位标题推断匹配的本平台岗位
 */
function inferMatchingJobs(title) {
  const matches = [];
  const titleLower = title.toLowerCase();

  // 云计算方向
  if (titleLower.includes('云运维') || titleLower.includes('cloud ops')) {
    matches.push('cl-ops', 'cl-idc');
  }
  if (titleLower.includes('虚拟化') || titleLower.includes('virtual')) {
    matches.push('cl-virt');
  }
  if (titleLower.includes('k8s') || titleLower.includes('容器') || titleLower.includes('docker')) {
    matches.push('cl-k8s');
  }
  if (titleLower.includes('云网络') || titleLower.includes('cloud network')) {
    matches.push('cl-net');
  }
  if (titleLower.includes('云迁移') || titleLower.includes('migration')) {
    matches.push('cl-migrate');
  }
  if (titleLower.includes('云售前') || titleLower.includes('cloud presales')) {
    matches.push('cl-presales');
  }

  // 大数据方向
  if (titleLower.includes('etl') || titleLower.includes('数据开发')) {
    matches.push('bd-etl', 'bd-platform');
  }
  if (titleLower.includes('数据仓库') || titleLower.includes('数仓')) {
    matches.push('bd-dw');
  }
  if (titleLower.includes('实时计算') || titleLower.includes('flink') || titleLower.includes('spark')) {
    matches.push('bd-realtime');
  }
  if (titleLower.includes('bi') || titleLower.includes('可视化') || titleLower.includes('报表')) {
    matches.push('bd-bi');
  }
  if (titleLower.includes('数据治理')) {
    matches.push('bd-gov');
  }
  if (titleLower.includes('数据分析') || titleLower.includes('analyst')) {
    matches.push('bd-analyst');
  }

  // AI方向
  if (titleLower.includes('模型部署') || titleLower.includes('推理') || titleLower.includes('inference')) {
    matches.push('ai-deploy');
  }
  if (titleLower.includes('计算机视觉') || titleLower.includes('cv') || titleLower.includes('图像')) {
    matches.push('ai-cv');
  }
  if (titleLower.includes('大模型') || titleLower.includes('llm') || titleLower.includes('nlp')) {
    matches.push('ai-llm');
  }
  if (titleLower.includes('标注') || titleLower.includes('annotation')) {
    matches.push('ai-label');
  }
  if (titleLower.includes('ai运维') || titleLower.includes('ai平台')) {
    matches.push('ai-platform-ops');
  }
  if (titleLower.includes('ai方案') || titleLower.includes('ai售前')) {
    matches.push('ai-solution');
  }
  if (titleLower.includes('边缘') || titleLower.includes('edge')) {
    matches.push('ai-edge');
  }

  // 鸿蒙方向
  if (titleLower.includes('鸿蒙') || titleLower.includes('harmonyos') || titleLower.includes('arkts')) {
    matches.push('hm-app', 'hm-ui');
  }
  if (titleLower.includes('嵌入式') || titleLower.includes('驱动')) {
    matches.push('hm-embedded', 'hm-driver');
  }
  if (titleLower.includes('物联网') || titleLower.includes('iot')) {
    matches.push('hm-iot');
  }

  // 数通方向
  if (titleLower.includes('网络工程师') || titleLower.includes('网络实施')) {
    matches.push('dc-campus', 'dc-onsite');
  }
  if (titleLower.includes('路由') || titleLower.includes('ospf') || titleLower.includes('bgp')) {
    matches.push('dc-route');
  }
  if (titleLower.includes('交换') || titleLower.includes('vlan')) {
    matches.push('dc-switch');
  }
  if (titleLower.includes('wlan') || titleLower.includes('无线')) {
    matches.push('dc-wlan');
  }
  if (titleLower.includes('sd-wan') || titleLower.includes('广域网')) {
    matches.push('dc-sdwan');
  }

  // 如果没匹配到，返回通用匹配
  if (matches.length === 0) {
    matches.push('support');
  }

  return matches;
}

/**
 * 根据经验和学历推断适配阶段
 */
function inferFitStage(exp, edu) {
  if (exp.includes('应届') || exp.includes('实习') || exp.includes('在校生')) {
    return 'graduate';
  }
  if (exp.includes('3-5年') || exp.includes('5年') || exp.includes('资深') || exp.includes('专家')) {
    return 'advanced';
  }
  return 'target'; // 默认 1-3 年
}

/**
 * 主更新流程
 */
async function updateJobs() {
  console.log('=== 开始更新岗位库数据 ===\n');

  // 1. 抓取职位列表
  const jobList = await fetchJobList();
  
  if (jobList.length === 0) {
    console.log('未能抓取到职位数据，请检查网络连接或稍后重试');
    return { success: false, message: '未能抓取到职位数据' };
  }

  // 2. 抓取前 20 个职位的详情（避免请求过多）
  const jobsToFetch = jobList.slice(0, 20);
  console.log(`\n正在抓取 ${jobsToFetch.length} 个职位的详细信息...`);
  
  const newJobs = [];
  for (let i = 0; i < jobsToFetch.length; i++) {
    const job = jobsToFetch[i];
    console.log(`  [${i + 1}/${jobsToFetch.length}] ${job.title || job.id}`);
    
    const detail = await fetchJobDetail(job.id);
    if (detail) {
      newJobs.push(detail);
    }
    
    // 添加延迟，避免请求过快
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  // 3. 读取现有的 zqt.js
  const zqtPath = path.join(__dirname, '..', 'assets', 'zqt.js');
  if (!fs.existsSync(zqtPath)) {
    console.error('找不到 zqt.js 文件:', zqtPath);
    return { success: false, message: '找不到 zqt.js 文件' };
  }

  let zqtContent = fs.readFileSync(zqtPath, 'utf8');

  // 4. 更新 jobs 数组
  // 找到 jobs 数组的位置
  const jobsArrayMatch = zqtContent.match(/"jobs":\s*\[([\s\S]*?)\n\s*\]/);
  
  if (!jobsArrayMatch) {
    console.error('无法在 zqt.js 中找到 jobs 数组');
    return { success: false, message: '无法找到 jobs 数组' };
  }

  // 构建新的 jobs 数组内容
  const newJobsJson = JSON.stringify(newJobs, null, 2)
    .split('\n')
    .map(line => '    ' + line) // 添加缩进
    .join('\n');

  // 替换 jobs 数组
  const updatedContent = zqtContent.replace(
    /"jobs":\s*\[[\s\S]*?\n\s*\]/,
    `"jobs": [\n${newJobsJson}\n  ]`
  );

  // 5. 生成新文件
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const newFileName = `zqt-updated-${timestamp}.js`;
  const newFilePath = path.join(__dirname, '..', 'assets', newFileName);
  
  fs.writeFileSync(newFilePath, updatedContent, 'utf8');

  console.log(`\n=== 更新完成 ===`);
  console.log(`新文件已生成: ${newFilePath}`);
  console.log(`共更新 ${newJobs.length} 个职位`);
  console.log(`\n请手动将 ${newFileName} 重命名为 zqt.js 以应用更新`);

  return {
    success: true,
    message: '更新成功',
    newFile: newFileName,
    newFilePath: newFilePath,
    jobCount: newJobs.length
  };
}

// 如果直接运行脚本
if (require.main === module) {
  updateJobs().then(result => {
    process.exit(result.success ? 0 : 1);
  }).catch(error => {
    console.error('更新失败:', error);
    process.exit(1);
  });
}

module.exports = { updateJobs };
